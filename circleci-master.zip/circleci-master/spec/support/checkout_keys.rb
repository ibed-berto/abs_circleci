# frozen_string_literal: true

def test_checkout_key_fingerprint
  '3e:35:e0:96:f7:c8:23:9c:b8:2f:50:9e:d0:16:f7:05'
end

def test_delete_checkout_key_fingerprint
  '29:15:12:e8:f7:f4:17:7a:8f:cc:db:de:43:53:f4:73'
end
